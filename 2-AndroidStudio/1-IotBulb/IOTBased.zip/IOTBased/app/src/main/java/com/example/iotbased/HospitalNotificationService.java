package com.example.iotbased;

import android.app.IntentService;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.BitmapFactory;

import androidx.core.app.NotificationCompat;

import com.example.iotbased.ConfirmedHospitalListActivity;
import com.example.iotbased.databases.DatabaseHandler;
import com.example.iotbased.logics.P;
import com.example.iotbased.setgets.HospitalSetGet;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class HospitalNotificationService extends IntentService {


    public HospitalNotificationService() {
        super("HospitalNotificationService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        P.LogD("HospitalNotificationService Started");
        if (intent != null) {
            String desc = intent.getStringExtra("desc").toString().toLowerCase();
            desc = desc.substring(desc.indexOf("latlng")+6);
            P.LogD("HospitalNotificationService desc " + desc);
            String latlng[] = desc.split(",");
            String number=intent.getStringExtra("number");
            if(number.contains("+233"))
                number=number.replace("+233","0");
            if(number.contains("+91"))
                number=number.replace("+91", "");

            HospitalSetGet h = new DatabaseHandler(HospitalNotificationService.this).getHospitalFromNumber(number);
            P.hospitalSetGets.add(h);

            desc=h.getH_name()+"\n"+h.getH_address()+"\n"+h.getMobile_no();
            ShowNotification(desc, latlng[0], latlng[1]);
            NotifyListview();
        }
    }

    public void NotifyListview(){
        Intent intent=new Intent("com.notify.list");
        sendBroadcast(intent);
    }

    public void ShowNotification(String desc, String lat, String lng) {

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_dialog_alert);
        Intent intent = new Intent(HospitalNotificationService.this, ConfirmedHospitalListActivity.class);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);
        builder.setContentIntent(pendingIntent);
        builder.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher));
        builder.setContentTitle(getResources().getString(R.string.app_name));
        builder.setContentText(desc);
        builder.setSubText("Tap for navigation.");

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // Will display the notification in the notification bar
        notificationManager.notify(1, builder.build());

    }

}
