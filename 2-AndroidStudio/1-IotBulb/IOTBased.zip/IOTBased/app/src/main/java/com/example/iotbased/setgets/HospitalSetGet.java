package com.example.iotbased.setgets;

/**
 * Created by admin on 09/02/2017.
 */
public class HospitalSetGet {

    //WRITE THE VARIABLES
    public String h_id;
    public String h_name;
    public String h_address;
    public String h_lat;
    public String h_lng;
    public String mobile_no;

    //TO CRAATE THIS CONSTRUCTOR, PRESS ALT+INSERT AND CLICK ON CONSTRUCROR, AND THEN SELECT VARIABLES
    public HospitalSetGet(String h_id, String h_name, String h_address, String h_lat, String h_lng, String mobile_no) {
        this.h_id = h_id;
        this.h_name = h_name;
        this.h_address = h_address;
        this.h_lat = h_lat;
        this.h_lng = h_lng;
        this.mobile_no = mobile_no;
    }

    //TO CREATE THESE GETTERS, PRESS ALT+INSERT AND CLICK ON GETTERS
    public String getH_id() {
        return h_id;
    }

    public String getH_name() {
        return h_name;
    }

    public String getH_address() {
        return h_address;
    }

    public String getH_lat() {
        return h_lat;
    }

    public String getH_lng() {
        return h_lng;
    }

    public String getMobile_no() {
        return mobile_no;
    }
}
