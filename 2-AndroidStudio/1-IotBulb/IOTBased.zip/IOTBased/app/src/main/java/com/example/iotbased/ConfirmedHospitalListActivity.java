package com.example.iotbased;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.iotbased.adapters.HospitalAdapter;
import com.example.iotbased.databases.DatabaseHandler;
import com.example.iotbased.logics.P;
import com.example.iotbased.setgets.HospitalSetGet;

import java.util.ArrayList;
import java.util.List;

//import butterknife.Bind;
//import butterknife.ButterKnife;

public class ConfirmedHospitalListActivity extends AppCompatActivity {
//    @Bind(R.id.listView)
    ListView listView;
    Context context;
    DatabaseHandler db;
    HospitalAdapter hospitalAdapter;//ADAPETR DECLARATION
    List<HospitalSetGet> hospitalSetGets = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital_list);
//        ButterKnife.bind(this);
        context = ConfirmedHospitalListActivity.this;
        db = new DatabaseHandler(context);

        registerReceiver(notify_receiver, new IntentFilter("com.notify.list"));

        //GET THE DATA FROM DATABASE
        hospitalSetGets = P.hospitalSetGets;

        //INITIALISE ADAPTER
        hospitalAdapter = new HospitalAdapter(context, hospitalSetGets);

        //APPLY ADAPTER TO LISTVIEW
        listView.setAdapter(hospitalAdapter);

        //LONG CLICK LISTEMER TO LISTVIEW
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                HospitalSetGet hospitalSetGet = hospitalSetGets.get(position);
                db.deleteHospital(hospitalSetGet.h_id);
                hospitalSetGets.remove(position);
                hospitalAdapter.notifyDataSetChanged();
                Toast.makeText(context, "Successfully Deleted", Toast.LENGTH_LONG).show();
                return false;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                HospitalSetGet h = hospitalSetGets.get(i);
                String desc = h.getH_name() + "\n" + h.getH_address() + "\n" + h.getMobile_no();
                P.sendSMS(h.getMobile_no(),h.getH_name()+" Has been Selected");
                //for (int j=0;j<hospitalSetGets.size();j++) P.sendSMS(hospitalSetGets.get(j).getMobile_no(),h.getH_name()+" Has been Selected");



                String geoCode = "geo:0,0?q=" + h.getH_lat() + ","
                        + h.getH_lng() + "(" + desc + ")";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoCode));
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_hospital_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    BroadcastReceiver notify_receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            hospitalSetGets = P.hospitalSetGets;
            hospitalAdapter.notifyDataSetChanged();
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(notify_receiver);
    }
}
