package com.example.iotbased.databases;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by admin on 06-Feb-16.
 */

//Shared Preference Handler
public class SPH {

    //Account opening
    public static final String AccOpenStepsPref = "AccOpenStepsPref";
    public static final String AccOpenStep = "AccOpenStep";
    public static final String AccName = "AccName";
    public static final String AccPk = "AccPk";

    //Account opening Steps save
    public static void SaveInSharedPref(Context context, int step, String name, String pk) {
        SharedPreferences.Editor editor = context.getSharedPreferences(AccOpenStepsPref, context.MODE_PRIVATE).edit();
        editor.putInt(AccOpenStep, step);
        editor.putString(AccName, name);
        editor.putString(AccPk, pk);
        editor.commit();
    }

    public static SharedPreferences getAccOpenStepsPref(Context context) {
        return context.getSharedPreferences(AccOpenStepsPref, context.MODE_PRIVATE);
    }
}
