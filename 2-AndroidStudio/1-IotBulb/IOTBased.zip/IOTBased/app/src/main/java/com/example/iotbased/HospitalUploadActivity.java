package com.example.iotbased;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.iotbased.databases.DatabaseHandler;

//import butterknife.Bind;
//import butterknife.ButterKnife;

public class HospitalUploadActivity extends AppCompatActivity {
    private EditText edt_name, edt_address, edt_mobile_no,edt_lat,edt_lng;
    private Button btn_submit, btn_hospital_list;
//    @Bind(R.id.edt_name)
//    EditText edt_name;
//    @Bind(R.id.edt_address)
//    EditText edt_address;
//    @Bind(R.id.edt_mobile_no)
//    EditText edt_mobile_no;
//    @Bind(R.id.edt_lat)
//    EditText edt_lat;
//    @Bind(R.id.edt_lng)
//    EditText edt_lng;
//
//    @Bind(R.id.btn_submit)
//    Button btn_submit;
//    @Bind(R.id.btn_hospital_list)
//    Button btn_hospital_list;
    Context context;//CONTEXT DECLARATION
    DatabaseHandler db;//DATABASE DECLERATION

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital_upload);//LINKING XML
        edt_address= (EditText) findViewById(R.id.edt_address);
        edt_mobile_no= (EditText) findViewById(R.id.edt_mobile_no);
        edt_lat= (EditText) findViewById(R.id.edt_lat);
        edt_lng= (EditText) findViewById(R.id.edt_lng);
        edt_name = (EditText) findViewById(R.id.edt_name);
        btn_submit = (Button) findViewById(R.id.btn_submit);
        btn_hospital_list = (Button) findViewById(R.id.btn_hospital_list);
//        ButterKnife.bind(this);//BUUTERNIFE INITIALIZATION
        context = HospitalUploadActivity.this;//INITIAZING CONTEXT
        db = new DatabaseHandler(context);//INITAIZING DB(CREATING OBJECT OF CLASS)

        //SUBMIT BUTTON CLICK LISTENER
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //CALL FIELDS VALIDATION FUNCTION
                Validation();
            }
        });

        //HOSPITAL LIST BUTTON CLICK LISTENER
        btn_hospital_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //OPEN HOSPITAL ACTIVITY
                Intent intent=new Intent(context,HospitalListActivity.class);
                startActivity(intent);
            }
        });

    }

    //VALIDATION FOR FIELDS
    public void Validation() {
        if (edt_name.getText().toString().trim().isEmpty()) {
            edt_name.setError("Please enter hosptal name");
            return;//DO NOT CONTINUE TO NEXT INSTRUCTION
        }
        if (edt_address.getText().toString().trim().isEmpty()) {
            edt_address.setError("Please enter address");
            return;
        }
        if (edt_mobile_no.getText().toString().trim().isEmpty() || edt_mobile_no.getText().toString().trim().length() != 10) {
            edt_mobile_no.setError("Please enter valid mobile number");
            return;
        }
        if (edt_lat.getText().toString().trim().isEmpty()) {
            edt_lat.setError("Please enter lattitude");
            return;
        }
        if (edt_lng.getText().toString().trim().isEmpty()) {
            edt_lng.setError("Please enter longitude");
            return;
        }

        //NOW INSERT THE DATA INTO DATABASE
        db.insertIntoHosptal(
                edt_name.getText().toString().trim(),
                edt_address.getText().toString().trim(),
                edt_lat.getText().toString().trim(),
                edt_lng.getText().toString().trim(),
                edt_mobile_no.getText().toString().trim()
        );

        //SHOW TOAST MESSAGE
        Toast.makeText(context, "Successfully Saved", Toast.LENGTH_LONG).show();

        //CALL FUNCTION TO CLEAR FIELDS
        ClearFields();


    }

    //CLEAR THE FIELDS
    public void ClearFields() {
        edt_name.setText("");
        edt_address.setText("");
        edt_mobile_no.setText("");
        edt_lat.setText("");
        edt_lng.setText("");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_hospital_upload, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
