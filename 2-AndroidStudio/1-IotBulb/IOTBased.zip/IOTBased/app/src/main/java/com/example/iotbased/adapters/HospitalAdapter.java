package com.example.iotbased.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.iotbased.setgets.HospitalSetGet;
import com.example.iotbased.R;
import com.example.iotbased.setgets.HospitalSetGet;

import java.util.List;


/**
 * Created by Admin on 1/5/2016.
 */
public class HospitalAdapter extends BaseAdapter {
    private Context context;
    private List<HospitalSetGet> hospitalSetGets;

    @Override
    public int getCount() {
        return hospitalSetGets.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public HospitalAdapter(Context context, List<HospitalSetGet> hospitalSetGets) {
        this.context = context;
        this.hospitalSetGets = hospitalSetGets;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView;
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        rowView = layoutInflater.inflate(R.layout.listview_hosptal_row_item, null);

        TextView txt_name = (TextView) rowView.findViewById(R.id.txt_name);
        TextView txt_address = (TextView) rowView.findViewById(R.id.txt_address);
        TextView txt_mobile_no = (TextView) rowView.findViewById(R.id.txt_mobile_no);
        TextView txt_lat = (TextView) rowView.findViewById(R.id.txt_lat);
        TextView txt_lng = (TextView) rowView.findViewById(R.id.txt_lng);
        HospitalSetGet hospitalSetGet = hospitalSetGets.get(position);


             txt_name.setText("Name    : " + hospitalSetGet.getH_name());
          txt_address.setText("Address : " + hospitalSetGet.getH_address());
        txt_mobile_no.setText("Mob     : " + hospitalSetGet.getMobile_no());
              txt_lat.setText("Lat     : " + hospitalSetGet.getH_lat());
              txt_lng.setText("Lng     : " + hospitalSetGet.getH_lng());
        return rowView;
    }
}
