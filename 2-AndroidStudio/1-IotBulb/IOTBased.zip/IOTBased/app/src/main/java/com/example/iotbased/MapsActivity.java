package com.example.iotbased;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.iotbased.databases.DatabaseHandler;
import com.example.iotbased.logics.P;
import com.example.iotbased.setgets.HospitalSetGet;

import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap; // Might be null if Google Play services APK is not available.
    Context context;
    DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        context = MapsActivity.this;
        db = new DatabaseHandler(context);
        SupportMapFragment supportMapFragment = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map));
        supportMapFragment.getMapAsync(this);
        // P.sendSMS("8151936741", getDataToSend(12.976, 76.86876));
        //Intent intent = new Intent(context, HospitalUploadActivity.class);
        //startActivity(intent);
    }

    private void setUpMap() {
        mMap.getUiSettings();
        locateHospitals();
        mMap.setMyLocationEnabled(true);
        mMap.setOnMyLocationChangeListener(new GoogleMap.OnMyLocationChangeListener() {
            @Override
            public void onMyLocationChange(Location location) {
                double lat = location.getLatitude();
                double lng = location.getLongitude();
                //mMap.addMarker(new MarkerOptions().position(new LatLng(lat, lng)).title("I am here"));

                //P.sendSMS("8151936741", getDataToSend(lat, lng));
            }
        });
    }

    public String getDataToSend(double lat, double lng) {
        String data="";
        if(getIntent().getStringExtra("h_data") !=null){
            data = getIntent().getStringExtra("h_data")+"\n";
        }
        data = data + "Location: LatLng " + lat + "," + lng + " \n";
        return data;
    }

    public void locateHospitals() {
        List<HospitalSetGet> hospitalSetGets = db.getAllHospitals();
        for (int i = 0; i < hospitalSetGets.size(); i++) {
            HospitalSetGet hospitalSetGet = hospitalSetGets.get(i);
            double lat = Double.parseDouble(hospitalSetGet.getH_lat());
            double lng = Double.parseDouble(hospitalSetGet.getH_lng());
            mMap.addMarker(new MarkerOptions().position(new LatLng(lat, lng)).title(hospitalSetGet.getH_name()).snippet(hospitalSetGet.getH_address() + "-" + hospitalSetGet.getMobile_no()));
            P.LogD("Mobile Number To SMS : " + hospitalSetGet.getMobile_no());
            if(getIntent().getStringExtra("h_data") !=null) {
                P.sendSMS(hospitalSetGet.getMobile_no(), "FromSA:\n" + getDataToSend(lat, lng));
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (mMap != null) {
            setUpMap();

        }
    }
}
