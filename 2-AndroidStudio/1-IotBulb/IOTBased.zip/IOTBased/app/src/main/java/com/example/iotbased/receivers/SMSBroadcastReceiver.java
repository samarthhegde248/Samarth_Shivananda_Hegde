package com.example.iotbased.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

import com.example.iotbased.HospitalNotificationService;
import com.example.iotbased.R;
import com.example.iotbased.bluetooth.BluetoothActivity;


/**
 * Created by PRASAD on 26-04-2016.
 */
public class SMSBroadcastReceiver extends BroadcastReceiver {
    private static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
    private static final String TAG = "SMSBroadcastReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "Intent recieved: " + intent.getAction());

        if (intent.getAction().equals(SMS_RECEIVED)) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                Object[] pdus = (Object[]) bundle.get("pdus");
                final SmsMessage[] messages = new SmsMessage[pdus.length];
                for (int i = 0; i < pdus.length; i++) {
                    messages[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                }
                if (messages.length > -1) {
                    Log.d(TAG, "Number: " + messages[0].getOriginatingAddress());
                    Log.d(TAG, "Msg: " + messages[0].getMessageBody());
                    if (messages[0].getMessageBody().toLowerCase().contains("smartambulance")) {

                        Intent i = new Intent();
                        i.setClassName("com.pmaptechnotech.admin.smartambulance", "com.pmaptechnotech.admin.smartambulance.activities.MapsActivity");
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(i);
                    } else if (messages[0].getMessageBody().toLowerCase().contains("fromsa")) {
                        Intent i = new Intent();
                        i.setClassName("com.pmaptechnotech.admin.smartambulance", "com.pmaptechnotech.admin.smartambulance.hospital_panel.SmsFromSmartAmbulanceActivity");
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        i.putExtra("desc",messages[0].getMessageBody());
                        i.putExtra("number",messages[0].getOriginatingAddress());
                        context.startActivity(i);
                    } else if (messages[0].getMessageBody().toLowerCase().contains("fromhospital")) {
                        Intent intent2 = new Intent(context, HospitalNotificationService.class);
                        intent2.putExtra("number",messages[0].getOriginatingAddress());
                        intent2.putExtra("desc",messages[0].getMessageBody());
                        context.startService(intent2);
                    } else if (messages[0].getMessageBody().toLowerCase().contains("alert")) {
                        MediaPlayer mPlayer = MediaPlayer.create(context, R.raw.thuje);
                        mPlayer.start();
                    }else if (messages[0].getMessageBody().toLowerCase().contains("on")) {
                        Intent intent2 = new Intent(context, BluetoothActivity.class);
                        intent2.putExtra("message","1");
                        intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent2);
                    }
                    else if (messages[0].getMessageBody().toLowerCase().contains("off")) {
                        Intent intent2 = new Intent(context, BluetoothActivity.class);
                        intent2.putExtra("message","0");
                        intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent2);
                    }

                    //Toast.makeText(context, "Message received: " + messages[0].getMessageBody(), Toast.LENGTH_LONG).show();
                }
            }
        }

    }
}
