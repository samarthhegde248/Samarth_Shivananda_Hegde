package com.example.iotbased;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.iotbased.bluetooth.BluetoothActivity;
import com.example.iotbased.bluetooth.BluetoothDemoActivity;
import com.example.iotbased.logics.P;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.UUID;

//import butterknife.Bind;
//import butterknife.ButterKnife;


public class BulbOnOffActivity extends AppCompatActivity {
    private ImageView img_on_off_bulb;
    private Button btn_on_off_bulb, btn_mic_on_off_bulb;
//    @Bind(R.id.img_on_off_bulb)
//    ImageView img_on_off_bulb;
//    @Bind(R.id.btn_on_off_bulb)
//    Button btn_on_off_bulb;
//    @Bind(R.id.btn_mic_on_off_bulb)
//    Button btn_mic_on_off_bulb;
    private static boolean isBulbOn = false;
    private int WHAT = 0;
    private SpeechRecognizer mSpeechRecognizer;
    private Intent mSpeechRecognizerIntent;
    private boolean mIslistening = false;
    private String TAG = "BulbOnOff";
    private TextToSpeech t1;
    HashMap<String, String> params = new HashMap<String, String>();
    public static final String CONTROL = "control";
    public static final String ALERT = "alert";
    private Context context;

    //BLUETOOTH
    //ANOTHER SET

    /*Adapter helps to get a handler for device object which can be used to communicate with Bluetooth module*/
    private BluetoothAdapter btAdapter = null;
    /* Socket is used to connect and to get output/input streams to write/Read data To/From Bluetooth module */
    private BluetoothSocket btSocket = null;

    /* Output stream used to send data to Bluetooth module
     private OutputStream outStream = null;

    /* input stream used to read data from Bluetooth module */
    private InputStream inStream;

    // UUID is used as a key to connect to the device
    private final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // Insert your server's MAC address
    private String address = "98:D3:31:FB:47:46";
    //private static String address = "98:D3:31:FC:46:A8";//Divya
    Thread thread;
    OutputStream outStream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bulb_on_off);
        img_on_off_bulb = (ImageView) findViewById(R.id.img_on_off_bulb);
        btn_on_off_bulb =(Button) findViewById(R.id.btn_on_off_bulb);
        btn_mic_on_off_bulb =(Button) findViewById(R.id.btn_mic_on_off_bulb);
//        ButterKnife.bind(this);
        context = BulbOnOffActivity.this;

        speechRecognitionInit();
        t1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    t1.setLanguage(Locale.ENGLISH);
                    int isSpeechRate = t1.setSpeechRate(Float.parseFloat("0.9"));
                    P.LogD("isSpeechRate: " + isSpeechRate);
                    int isPitch = t1.setPitch(Float.parseFloat("0.8"));
                    P.LogD("isPitch: " + isPitch);
                }
            }
        });
        t1.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {

            }

            @Override
            public void onDone(String utteranceId) {
                switch (utteranceId) {
                    case CONTROL:
                        startListening();
                        break;
                    case ALERT:
                        //startListening();
                        break;
                }

            }

            @Override
            public void onError(String utteranceId) {

            }
        });
        btn_on_off_bulb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleBulb();
            }
        });

        btn_mic_on_off_bulb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ask("What Can I Do for You", CONTROL);
            }
        });

        img_on_off_bulb.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Intent intent = new Intent(context, BluetoothDemoActivity.class);
                startActivity(intent);
                return false;
            }
        });
        btn_mic_on_off_bulb.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Intent intent = new Intent(context, BluetoothActivity.class);
                startActivity(intent);
                return false;
            }
        });
        try {
            btAdapter = BluetoothAdapter.getDefaultAdapter();
            checkBTState();
            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    //Create a thread which infinitely listen to the incoming data
                    //listen();
                    //ReadBluetoothData();
                    //sendData("1");
                }
            };
            thread = new Thread(runnable);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }


    }

    private void ask(String msg, String key) {
        params.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, key);
        t1.speak(msg, TextToSpeech.QUEUE_FLUSH, params);
    }

    public void startListening() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                mSpeechRecognizer.startListening(mSpeechRecognizerIntent);

            }
        });
    }

    private void toggleBulb() {
        if (isBulbOn) {
            offBulb();
        } else {
            onBulb();
        }
    }

    private void onBulb() {
        sendDataToBluetooth("1");
        isBulbOn = true;
        img_on_off_bulb.setBackgroundResource(R.drawable.img_on_state);
        btn_on_off_bulb.setBackgroundResource(R.drawable.img_switch_on);
    }

    private void offBulb() {
        sendDataToBluetooth("0");
        isBulbOn = false;
        img_on_off_bulb.setBackgroundResource(R.drawable.img_off_state);
        btn_on_off_bulb.setBackgroundResource(R.drawable.img_switch_off);
    }

    public void speechRecognitionInit() {
        mSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        mSpeechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        mSpeechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        mSpeechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE,
                this.getPackageName());


        SpeechRecognitionListener listener = new SpeechRecognitionListener();
        mSpeechRecognizer.setRecognitionListener(listener);
    }

    protected class SpeechRecognitionListener implements RecognitionListener {

        @Override
        public void onBeginningOfSpeech() {
            P.LogD("Chatting On onBeginningOfSpeech");
        }

        @Override
        public void onBufferReceived(byte[] buffer) {

        }

        @Override
        public void onEndOfSpeech() {
            P.LogD("Chatting On onEndOfSpeech");
        }

        @Override
        public void onError(int errorCode) {
            mSpeechRecognizer.startListening(mSpeechRecognizerIntent);
            String errorMessage = getErrorText(errorCode);
            P.LogD("Chatting On onError : " + errorMessage);
            if (errorMessage.equalsIgnoreCase("No match")) {
                return;
            }
            //Log.d(TAG, "error = " + error);
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
            P.LogD("Chatting On onEvent");
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
            P.LogD("Chatting On onPartialResults");
        }

        @Override
        public void onReadyForSpeech(Bundle params) {
            Log.d(TAG, "onReadyForSpeech"); //$NON-NLS-1$
            P.LogD("Chatting On onReadyForSpeech");
        }

        @Override
        public void onResults(Bundle results) {
            //Log.d(TAG, "onResults"); //$NON-NLS-1$
            ArrayList<String> result = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            // matches are the return values of speech recognition engine
            // Use these values for whatever you wish to do

            P.LogD("Chatting On onResult : " + result.get(0));
            switch (WHAT) {
                case P.FOR_SPEECH_INPUT: {
                    String speechInput = result.get(0).trim().replace(" ", "");
                    if (speechInput.toLowerCase().contains("on")) {
                        if (isBulbOn) {
                            ask("Bulb is already Switched ON", ALERT);
                        }
                        onBulb();
                    } else if (speechInput.toLowerCase().contains("off")) {
                        offBulb();
                    }

                }

                break;

                default:
                    break;
            }
        }

        @Override
        public void onRmsChanged(float rmsdB) {
        }


    }


    public static String getErrorText(int errorCode) {
        String message;
        switch (errorCode) {
            case SpeechRecognizer.ERROR_AUDIO:
                message = "Audio recording error";
                break;
            case SpeechRecognizer.ERROR_CLIENT:
                message = "Client side error";
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                message = "Insufficient permissions";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
                message = "Network error";
                break;
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                message = "Network timeout";
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                message = "No match";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                message = "RecognitionService busy";
                break;
            case SpeechRecognizer.ERROR_SERVER:
                message = "error from server";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                message = "No speech input";
                break;
            default:
                message = "Didn't understand, please try again.";
                break;
        }
        return message;
    }

    private void sendDataToBluetooth(final String message) {
        Intent intent = new Intent(context, BluetoothActivity.class);
        intent.putExtra("message", message);
        //startActivity(intent);
        sendData(message);
       /* try {
            //btAdapter = BluetoothAdapter.getDefaultAdapter();
            checkBTState();
            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    //Create a thread which infinitely listen to the incoming data
                    //listen();
                    //ReadBluetoothData();
                    sendData(message);
                }
            };
            thread = new Thread(runnable);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }*/
    }

    @Override
    public void onResume() {
        super.onResume();
        // Set up a pointer to the remote node using it's address.
        BluetoothDevice device = btAdapter.getRemoteDevice(address);
        // Two things are needed to make a connection:
        //   A MAC address, which we got above.
        //   A Service ID or UUID.  In this case we are using the
        //     UUID for SPP.
        try {
            btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
        } catch (IOException e) {
            errorExit("Fatal Error", "In onResume() and socket create failed: " + e.getMessage() + ".");
        }
        // Discovery is resource intensive.  Make sure it isn't going on
        // when you attempt to connect and pass your message.
        btAdapter.cancelDiscovery();
        // Establish the connection.  This will block until it connects.
        try {
            btSocket.connect();
        } catch (IOException e) {
            try {
                btSocket.close();
            } catch (IOException e2) {

            }
        } catch (NullPointerException e) {
            e.printStackTrace();
            Toast.makeText(context, "Please check device pairing, device address", Toast.LENGTH_LONG).show();

        }
// Create a data stream so we can talk to server.
        try {
            outStream = btSocket.getOutputStream();
            inStream = btSocket.getInputStream();
            if (thread.getState() == Thread.State.NEW) {
                thread.start();
            }
        } catch (IOException e) {
        } catch (NullPointerException e) {
            e.printStackTrace();
            Toast.makeText(context, "Please check device pairing, device address", Toast.LENGTH_LONG).show();

        }
    }

    //Run listen in different thread
    public void listen() {
        // Keep listening to the InputStream until an exception occurs
        while (true) {
            try {
                // Read from the InputStream
                byte buffer[];
                buffer = new byte[1024];
                //Read is synchronous call which keeps on waiting until data is available
                int bytes = inStream.read(buffer);
                if (bytes > 0) {
                    //  Toast.makeText(BluetoothActivity.this,"Data",Toast.LENGTH_LONG).show();
                    P.LogD("Dataa1 : " + inStream.toString());
                    //String theString = getStringFromInputStream(inStream);
                    int byteCount = inStream.available();
                    if (byteCount > 0) {
                        P.LogD("Blue 0 : ");
                        byte[] rawBytes = new byte[byteCount];
                        P.LogD("Blue 1 : ");
                        inStream.read(rawBytes);
                        P.LogD("Blue 2 : ");
                        final String string = new String(rawBytes, "UTF-8");
                        P.LogD("Dataaa2 : " + string);
                        P.LogD("Blue 3 : ");

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //txt_data.setText(string);
                                // Toast.makeText(BluetoothActivity.this, string, Toast.LENGTH_LONG).show();
                                String h_data = "";
                                if (string.trim().toLowerCase().contains(",")) {
                                    String h_rate = string.split(",")[0];
                                    String b_temp = string.split(",")[1];
                                    if (h_rate.trim().length() == 1) {
                                        h_rate = "7" + h_rate;
                                    }
                                    if (b_temp.trim().length() == 1) {
                                        b_temp = "7" + b_temp;
                                    }
                                    h_data = "Heart Rate : " + h_rate + ", Body Temp : " + b_temp;
                                    Intent intent = new Intent(context, MapsActivity.class);
                                    intent.putExtra("h_data", h_data);
                                    startActivity(intent);
                                    finish();
                                }
                            }
                        });

                       /* new Handler().post(new Runnable() {
                            public void run()
                            {
                                myLabel.append(string);
                            }
                        });*/

                    }

              /*If data is non zero which means a data has been sent from Arduino to
               Android */
                    //Do your stuff here
                }
            } catch (IOException e) {
                break;
            }
        }
    }

    private void checkBTState() {
        // Check for Bluetooth support and then check to make sure it is turned on
        // Emulator doesn't support Bluetooth and will return null
        if (btAdapter == null) {
        } else {
        }
    }


    private void sendData(String message) {
        byte[] msgBuffer = message.getBytes();
        try {
            outStream.write(msgBuffer);
        } catch (IOException e) {
            String msg = "In onResume() and an exception occurred during write: " + e.getMessage();
            if (address.equals("00:00:00:00:00:00"))
                msg = msg + ".\n\nUpdate your server address from 00:00:00:00:00:00 to the correct address on line 37 in the java code";
            msg = msg + ".\n\nCheck that the SPP UUID: " + MY_UUID.toString() + " exists on server.\n\n";
            errorExit("Fatal Error", msg);
        }catch (NullPointerException e){
            e.printStackTrace();
        }
    }


    public void errorExit(String err, String msg) {
        P.LogD("Bluetooth : " + err + " | " + msg);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mSpeechRecognizer != null) {
            mSpeechRecognizer.destroy();
        }
    }

}

