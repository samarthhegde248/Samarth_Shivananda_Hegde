package com.example.iotbased.databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.iotbased.logics.P;
import com.example.iotbased.setgets.HospitalSetGet;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Admin on 10/27/2015.
 */
public class DatabaseHandler extends SQLiteOpenHelper {
    private static final String tag = "DatabaseHandler";
    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 7;

    // Database Name
    private static final String DATABASE_NAME = "pmap";
    private Context context;

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;

    }

    //CREATING TABLES
    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_TABLE = "create table hospitals (h_id integer primary key autoincrement not null, h_name text,h_address text,h_lat text,h_lng text,h_mobile_no text)";
        db.execSQL(CREATE_TABLE);
    }

    // UPGRADING DATABASE
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS hospitals");
        onCreate(db);
    }

    //INSERT NEW HOSPITAL
    public void insertIntoHosptal(String h_name, String h_address, String h_lat, String h_lng, String h_mobile_no) {
        SQLiteDatabase db = this.getWritableDatabase();//TO WRITE INTO THE DATABASE
        ContentValues values = new ContentValues();//TO HOLD THE INPUT VALUES
        values.put("h_name", h_name);//COLUMN AND ITS VALUE
        values.put("h_address", h_address);
        values.put("h_lat", h_lat);
        values.put("h_lng", h_lng);
        values.put("h_mobile_no", h_mobile_no);
        db.insert("hospitals", null, values);
    }

    //GET ALL HOSPITALS
    public List<HospitalSetGet> getAllHospitals() {
        List<HospitalSetGet> hospitalSetGets = new ArrayList<>();//INITIALISE LIST ARRAY TO SAVE DATA
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from hospitals", null);
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    hospitalSetGets.add(new HospitalSetGet(
                            cursor.getString(cursor.getColumnIndex("h_id")),
                            cursor.getString(cursor.getColumnIndex("h_name")),
                            cursor.getString(cursor.getColumnIndex("h_address")),
                            cursor.getString(cursor.getColumnIndex("h_lat")),
                            cursor.getString(cursor.getColumnIndex("h_lng")),
                            cursor.getString(cursor.getColumnIndex("h_mobile_no"))
                    ));

                } while (cursor.moveToNext());
            }
        }
        return hospitalSetGets;
    }

    public HospitalSetGet getHospitalFromNumber(String h_mobile_no) {
        HospitalSetGet hospitalSetGet=null;
        String str = "Hosptal";
        SQLiteDatabase db = this.getReadableDatabase();
        String[] data = {h_mobile_no};
        Cursor cursor = db.rawQuery("select * from hospitals where h_mobile_no=?", data);
        if (cursor != null) {
            P.LogD("H Count: " + cursor.getCount());
            if (cursor.getCount() > 0) {
                if(cursor.moveToFirst()){
                    /*str="";
                    str+=cursor.getString(cursor.getColumnIndex("h_name"))+"\n";
                    str+=cursor.getString(cursor.getColumnIndex("h_address"))+"\n";
                    str+=cursor.getString(cursor.getColumnIndex("h_mobile_no"))+"\n";*/
                     hospitalSetGet=   new HospitalSetGet(
                            cursor.getString(cursor.getColumnIndex("h_id")),
                            cursor.getString(cursor.getColumnIndex("h_name")),
                            cursor.getString(cursor.getColumnIndex("h_address")),
                            cursor.getString(cursor.getColumnIndex("h_lat")),
                            cursor.getString(cursor.getColumnIndex("h_lng")),
                            cursor.getString(cursor.getColumnIndex("h_mobile_no")));
                }

            }
        }
        return hospitalSetGet;
    }

    //DELETE HOSPITAL
    public void deleteHospital(String h_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] data = {h_id};
        db.delete("hospitals", "h_id=?", data);
        db.close();
    }
}
