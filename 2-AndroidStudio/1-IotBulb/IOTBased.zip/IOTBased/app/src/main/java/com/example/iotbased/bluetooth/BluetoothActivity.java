package com.example.iotbased.bluetooth;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.iotbased.R;
import com.example.iotbased.MapsActivity;
import com.example.iotbased.logics.P;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

import static android.R.attr.data;

public class BluetoothActivity extends Activity {
    TextView myLabel;
    EditText myTextbox;
    BluetoothAdapter mBluetoothAdapter;
    BluetoothSocket mmSocket;
    BluetoothDevice mmDevice;
    OutputStream mmOutputStream;
    InputStream mmInputStream;
    Thread workerThread;
    byte[] readBuffer;
    int readBufferPosition;
    int counter;
    volatile boolean stopWorker;

    //ANOTHER SET

    /*Adapter helps to get a handler for device object which can be used to communicate with Bluetooth module*/
    private BluetoothAdapter btAdapter = null;
    /* Socket is used to connect and to get output/input streams to write/Read data To/From Bluetooth module */
    private BluetoothSocket btSocket = null;

    /* Output stream used to send data to Bluetooth module
     private OutputStream outStream = null;

    /* input stream used to read data from Bluetooth module */
    private InputStream inStream;

    // UUID is used as a key to connect to the device
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // Insert your server's MAC address
    private static String address = "98:D3:31:FB:47:46";
    //private static String address = "98:D3:31:FC:46:A8";//Divya
    Thread thread;
    OutputStream outStream;
    TextView txt_data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);
        txt_data = (TextView) findViewById(R.id.txt_data);
        txt_data.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent intent = new Intent(BluetoothActivity.this, BluetoothDemoActivity.class);
                startActivity(intent);
                return false;
            }
        });
      /*  Button openButton = (Button) findViewById(R.id.open);
        Button sendButton = (Button) findViewById(R.id.send);
        Button closeButton = (Button) findViewById(R.id.close);
        myLabel = (TextView) findViewById(R.id.label);
        myTextbox = (EditText) findViewById(R.id.entry);

        //Open Button
        openButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {

                    openBT();
                } catch (IOException ex) {
                }
            }
        });

        //Send Button
        sendButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                findBT();
               *//* try
                {

                    sendData();
                }
                catch (IOException ex) { }*//*
            }
        });

        //Close button
        closeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                try {
                    sendData();
                    //closeBT();
                } catch (IOException ex) {
                }
            }
        });*/
        try {
            btAdapter = BluetoothAdapter.getDefaultAdapter();
            checkBTState();
            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    //Create a thread which infinitely listen to the incoming data
                    //listen();
                    //ReadBluetoothData();
                    if (getIntent().getStringExtra("message") != null) {
                        String message = getIntent().getStringExtra("message");
                        sendData(message);
                    }
                }
            };
            thread = new Thread(runnable);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }

       /* new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
              String  h_data = "Heart Rate : 70, Body Temp : 73";
                Intent intent = new Intent(BluetoothActivity.this, MapsActivity.class);
                intent.putExtra("h_data", h_data);
                startActivity(intent);
                finish();
            }
        },10000);*/
    }

    @Override
    public void onResume() {
        super.onResume();
        // Set up a pointer to the remote node using it's address.
        BluetoothDevice device = btAdapter.getRemoteDevice(address);
        // Two things are needed to make a connection:
        //   A MAC address, which we got above.
        //   A Service ID or UUID.  In this case we are using the
        //     UUID for SPP.
        try {
            btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
        } catch (IOException e) {
            errorExit("Fatal Error", "In onResume() and socket create failed: " + e.getMessage() + ".");
        }
        // Discovery is resource intensive.  Make sure it isn't going on
        // when you attempt to connect and pass your message.
        btAdapter.cancelDiscovery();
        // Establish the connection.  This will block until it connects.
        try {
            btSocket.connect();
        } catch (IOException e) {
            try {
                btSocket.close();
            } catch (IOException e2) {

            }
        } catch (NullPointerException e) {
            e.printStackTrace();
            Toast.makeText(BluetoothActivity.this, "Please check device pairing, device address", Toast.LENGTH_LONG).show();

        }
// Create a data stream so we can talk to server.
        try {
            outStream = btSocket.getOutputStream();
            inStream = btSocket.getInputStream();
            if (thread.getState() == Thread.State.NEW) {
                thread.start();
            }
        } catch (IOException e) {
        } catch (NullPointerException e) {
            e.printStackTrace();
            Toast.makeText(BluetoothActivity.this, "Please check device pairing, device address", Toast.LENGTH_LONG).show();

        }
    }

    //Run listen in different thread
    public void listen() {
        // Keep listening to the InputStream until an exception occurs
        while (true) {
            try {
                // Read from the InputStream
                byte buffer[];
                buffer = new byte[1024];
                //Read is synchronous call which keeps on waiting until data is available
                int bytes = inStream.read(buffer);
                if (bytes > 0) {
                    //  Toast.makeText(BluetoothActivity.this,"Data",Toast.LENGTH_LONG).show();
                    P.LogD("Dataa1 : " + inStream.toString());
                    //String theString = getStringFromInputStream(inStream);
                    int byteCount = inStream.available();
                    if (byteCount > 0) {
                        P.LogD("Blue 0 : ");
                        byte[] rawBytes = new byte[byteCount];
                        P.LogD("Blue 1 : ");
                        inStream.read(rawBytes);
                        P.LogD("Blue 2 : ");
                        final String string = new String(rawBytes, "UTF-8");
                        P.LogD("Dataaa2 : " + string);
                        P.LogD("Blue 3 : ");

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                txt_data.setText(string);
                                // Toast.makeText(BluetoothActivity.this, string, Toast.LENGTH_LONG).show();
                                String h_data = "";
                                if (string.trim().toLowerCase().contains(",")) {
                                    String h_rate = string.split(",")[0];
                                    String b_temp = string.split(",")[1];
                                    if (h_rate.trim().length() == 1) {
                                        h_rate = "7" + h_rate;
                                    }
                                    if (b_temp.trim().length() == 1) {
                                        b_temp = "7" + b_temp;
                                    }
                                    h_data = "Heart Rate : " + h_rate + ", Body Temp : " + b_temp;
                                    Intent intent = new Intent(BluetoothActivity.this, MapsActivity.class);
                                    intent.putExtra("h_data", h_data);
                                    startActivity(intent);
                                    finish();
                                }
                            }
                        });

                       /* new Handler().post(new Runnable() {
                            public void run()
                            {
                                myLabel.append(string);
                            }
                        });*/

                    }

              /*If data is non zero which means a data has been sent from Arduino to
               Android */
                    //Do your stuff here
                }
            } catch (IOException e) {
                break;
            }
        }
    }

    public void ReadBluetoothData() {
        while (true) {
            // final Handler handler = new Handler();
            final byte delimiter = 10; //This is the ASCII code for a newline character
            P.LogD("Bluetooth Data 0 : ");
            stopWorker = false;
            readBufferPosition = 0;
            readBuffer = new byte[1024];
            try {
                //P.LogD("Bluetooth Data 2 : ");
                int bytesAvailable = inStream.available();
                if (bytesAvailable > 0) {
                    // P.LogD("Bluetooth Data 3 : ");
                    byte[] packetBytes = new byte[bytesAvailable];
                    inStream.read(packetBytes);
                    for (int i = 0; i < bytesAvailable; i++) {
                        //P.LogD("Bluetooth Data 4 : ");
                        byte b = packetBytes[i];
                        if (b == delimiter) {
                            P.LogD("Bluetooth Data 5 : ");
                            byte[] encodedBytes = new byte[readBufferPosition];
                            System.arraycopy(readBuffer, 0, encodedBytes, 0, encodedBytes.length);
                            final String data = new String(encodedBytes, "US-ASCII");
                            readBufferPosition = 0;
                            P.LogD("Bluetooth Data 6 : " + data);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    txt_data.setText(data);
                                    Toast.makeText(BluetoothActivity.this, data, Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(BluetoothActivity.this, MapsActivity.class);
                                    intent.putExtra("h_data", data);
                                    startActivity(intent);
                                    finish();

                                }
                            });
                        } else {
                            P.LogD("Bluetooth Data b else : " + data);
                            readBuffer[readBufferPosition++] = b;
                            P.LogD("Bluetooth Data a else : " + data);
                        }
                    }
                }
            } catch (IOException ex) {
                stopWorker = true;
            }
        }
    }

    private void checkBTState() {
        // Check for Bluetooth support and then check to make sure it is turned on
        // Emulator doesn't support Bluetooth and will return null
        if (btAdapter == null) {
        } else {
        }
    }


    private void sendData(String message) {
        byte[] msgBuffer = message.getBytes();
        try {
            outStream.write(msgBuffer);
        } catch (IOException e) {
            String msg = "In onResume() and an exception occurred during write: " + e.getMessage();
            if (address.equals("00:00:00:00:00:00"))
                msg = msg + ".\n\nUpdate your server address from 00:00:00:00:00:00 to the correct address on line 37 in the java code";
            msg = msg + ".\n\nCheck that the SPP UUID: " + MY_UUID.toString() + " exists on server.\n\n";
            errorExit("Fatal Error", msg);
        }


    }


    public void errorExit(String err, String msg) {
        P.LogD("Bluetooth : " + err + " | " + msg);
    }


    void findBT() {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            myLabel.setText("No bluetooth adapter available");
        }

        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBluetooth, 0);
        }

        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        String device_name = "";
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                P.LogD("Bluetooth Paired Devices : " + device.getName());
                if (device.getName().trim().equalsIgnoreCase("HC-05")) {
                    device_name = device.getName().trim();
                    mmDevice = device;
                    break;
                } else {
                    // mmDevice = device;
                    //break;

                }
            }
        }
        if (device_name.trim().isEmpty()) {
            Toast.makeText(BluetoothActivity.this, "HC-05 Device Not Paired or not connected", Toast.LENGTH_LONG).show();
        }
        myLabel.setText("Bluetooth Device Found : " + device_name);
    }

    void openBT() throws IOException {
        UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //Standard SerialPortService ID
        if (mmDevice == null) {
            myLabel.setText("Device Null");
            return;
        }
        BufferedReader mBufferedReader = null;
        InputStreamReader aReader = null;
        mmSocket = mmDevice.createRfcommSocketToServiceRecord(uuid);
        mmSocket.connect();
        mmOutputStream = mmSocket.getOutputStream();
        mmInputStream = mmSocket.getInputStream();
        P.LogD("Bluetooth My Data : 0");
        aReader = new InputStreamReader(mmInputStream);
        P.LogD("Bluetooth My Data : 1");
        mBufferedReader = new BufferedReader(aReader);
        P.LogD("Bluetooth My Data : 2");
        //String aString = mBufferedReader.readLine();

        //P.LogD("Bluetooth My Data : "+aString);
        beginListenForData();

        myLabel.setText("Bluetooth Opened");
    }

    void beginListenForData() {
        final Handler handler = new Handler();
        final byte delimiter = 10; //This is the ASCII code for a newline character
        P.LogD("Bluetooth Data 0 : ");
        stopWorker = false;
        readBufferPosition = 0;
        readBuffer = new byte[1024];
        P.LogD("Bluetooth Data 1 : ");
        workerThread = new Thread(new Runnable() {
            public void run() {
                while (!Thread.currentThread().isInterrupted() && !stopWorker) {
                    try {
                        P.LogD("Bluetooth Data 2 : ");
                        int bytesAvailable = mmInputStream.available();
                        if (bytesAvailable > 0) {
                            P.LogD("Bluetooth Data 3 : ");
                            byte[] packetBytes = new byte[bytesAvailable];
                            mmInputStream.read(packetBytes);
                            for (int i = 0; i < bytesAvailable; i++) {
                                P.LogD("Bluetooth Data 4 : ");
                                byte b = packetBytes[i];
                                //if (b == delimiter) {
                                P.LogD("Bluetooth Data 5 : ");
                                byte[] encodedBytes = new byte[readBufferPosition];
                                System.arraycopy(readBuffer, 0, encodedBytes, 0, encodedBytes.length);
                                final String data = new String(encodedBytes, "US-ASCII");
                                readBufferPosition = 0;
                                P.LogD("Bluetooth Data 6 : " + data);
                                handler.post(new Runnable() {
                                    public void run() {
                                        P.LogD("Bluetooth Data 7 : " + data);
                                        myLabel.setText(data);
                                    }
                                });
                               /* } else {
                                    P.LogD("Bluetooth Data b else : "+data);
                                    readBuffer[readBufferPosition++] = b;
                                    P.LogD("Bluetooth Data a else : "+data);
                                }*/
                            }
                        }
                    } catch (IOException ex) {
                        stopWorker = true;
                    }
                }
            }
        });

        workerThread.start();
    }

    void sendData() throws IOException {
        String msg = myTextbox.getText().toString();
        msg += "\n";
        mmOutputStream.write(msg.getBytes());
        myLabel.setText("Data Sent");
    }

    void closeBT() throws IOException {
        stopWorker = true;
        mmOutputStream.close();
        mmInputStream.close();
        mmSocket.close();
        myLabel.setText("Bluetooth Closed");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        },3000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (inStream != null)
                inStream.close();
            if (outStream != null)
                outStream.close();
            if (btSocket != null)
                btSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
