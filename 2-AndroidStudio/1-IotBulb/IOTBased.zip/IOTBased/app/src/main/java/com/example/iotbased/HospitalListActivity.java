package com.example.iotbased;

import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.iotbased.adapters.HospitalAdapter;
import com.example.iotbased.databases.DatabaseHandler;
import com.example.iotbased.setgets.HospitalSetGet;

import java.util.ArrayList;
import java.util.List;

//import butterknife.Bind;
//import butterknife.ButterKnife;

public class HospitalListActivity extends AppCompatActivity {
    private ListView listView;
//    @Bind(R.id.listView)
//    ListView listView;
    Context context;
    DatabaseHandler db;
    HospitalAdapter hospitalAdapter;//ADAPETR DECLARATION
    List<HospitalSetGet> hospitalSetGets = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital_list);
//        ButterKnife.bind(this);
        listView = (ListView) findViewById(R.id.listView);
        context = HospitalListActivity.this;
        db = new DatabaseHandler(context);

        //GET THE DATA FROM DATABASE
        hospitalSetGets = db.getAllHospitals();

        //INITIALISE ADAPTER
        hospitalAdapter = new HospitalAdapter(context, hospitalSetGets);

        //APPLY ADAPTER TO LISTVIEW
        listView.setAdapter(hospitalAdapter);

        //LONG CLICK LISTEMER TO LISTVIEW
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                HospitalSetGet hospitalSetGet = hospitalSetGets.get(position);
                db.deleteHospital(hospitalSetGet.h_id);
                hospitalSetGets.remove(position);
                hospitalAdapter.notifyDataSetChanged();
                Toast.makeText(context, "Successfully Deleted", Toast.LENGTH_LONG).show();
                return false;
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_hospital_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
