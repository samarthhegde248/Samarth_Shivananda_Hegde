package com.example.iotbased.hospital_panel;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.iotbased.R;
import com.example.iotbased.logics.P;

//import butterknife.Bind;
//import butterknife.ButterKnife;

public class SmsFromSmartAmbulanceActivity extends AppCompatActivity {
    private TextView txt_desc;
    private Button btn_confirm;
//    @Bind(R.id.txt_desc)
//    TextView txt_desc;
//    @Bind(R.id.btn_confirm)
//    Button btn_confirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_from_smart_ambulance);
        btn_confirm = (Button) findViewById(R.id.btn_confirm);
        txt_desc = (TextView) findViewById(R.id.txt_desc);
//        ButterKnife.bind(this);
        txt_desc.setText(getIntent().getStringExtra("desc"));
        btn_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String desc=getIntent().getStringExtra("desc");
                desc=desc.substring(desc.indexOf("Location"));
                String number=getIntent().getStringExtra("number");
                if(number.trim().length()>10){
                    number=number.substring(3);
                }
                P.sendSMS(number, "FromHospital:\n" +" "+desc);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_sms_from_smart_ambulance, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
