package com.example.user.wheelcontrol.combck;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.user.wheelcontrol.R;
import com.example.user.wheelcontrol.logics.P;

import java.util.List;
import java.util.Locale;

public class combck extends Activity {
    private TextToSpeech myTTS;
   private FloatingActionButton flotButton;
    private String message;
    private SpeechRecognizer mySpeech;
    private Intent mySpeechIntent;
    private String TAG = "WheelChair";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.comm);
flotButton = (FloatingActionButton) findViewById(R.id.flotButton);

        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    doPermAudio();
                }
            }
        });

flotButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        conductActivity4(v);

    }
});


    }

    public void conductActivity4(View view) {
        Snackbar.make(view,"I'm ready",Snackbar.LENGTH_SHORT).setAction("Action",null).show();
        InitilizeTexttoSpeech();
    }

    @Override
    protected void onPause() {
        super.onPause();
        myTTS.shutdown();
    }



    private void InitilizeTexttoSpeech() {
        myTTS = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (myTTS.getEngines().size() == 0) {
                    Toast.makeText(combck.this, "There is no TTS engine", Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    myTTS.setLanguage(Locale.ENGLISH);
                    speak("Hello, I'm ready.");
                    InitilizeSpeechRecognizer();

                }

            }
        });

    }

    private void speak(String message) {
        if(Build.VERSION.SDK_INT>=21){
            myTTS.speak(message, TextToSpeech.QUEUE_FLUSH,null, null);
        } else{
            myTTS.speak(message, TextToSpeech.QUEUE_FLUSH,null);

        }
    }

    private void InitilizeSpeechRecognizer() {
        if(SpeechRecognizer.isRecognitionAvailable(this)){
            mySpeech = SpeechRecognizer.createSpeechRecognizer(this);
            mySpeechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            mySpeechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            mySpeechIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getApplication().getPackageName());
            mySpeechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
            mySpeechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH);
            mySpeech.startListening(mySpeechIntent);
            mySpeech.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                    Log.d(TAG, "onReadyForSpeech"); //$NON-NLS-1$
                    P.LogD("Chatting On onReadyForSpeech");

                }

                @Override
                public void onBeginningOfSpeech() {
                    P.LogD("onBeginningOfSpeech");
                }

                @Override
                public void onRmsChanged(float rmsdB) {

                }

                @Override
                public void onBufferReceived(byte[] buffer) {

                }

                @Override
                public void onEndOfSpeech() {
                    P.LogD("onEndOfSpeech");
                }

                @Override
                public void onError(int error) {
                    mySpeech.startListening(mySpeechIntent);
                    String errorMessage = getErrorText(error);
                    P.LogD("onError : " + errorMessage);
                    if (errorMessage.equalsIgnoreCase("No match")) {
                        return;
                    }
                    //Log.d(TAG, "error = " + error);

                }

                @Override
                public void onResults(Bundle bundle) {
                    List<String> result = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    processResult(result.get(0));
                    P.LogD("Chatting On onResult : " + result.get(0));
                    switch (0) {
                        case P.FOR_SPEECH_INPUT: {
                            String speechInput = result.get(0).trim().replace(" ", "");
                            if (speechInput.toLowerCase().contains("front")) {
                                Toast.makeText(combck.this, "Moving Front", Toast.LENGTH_LONG).show();
                                speak("Moving Front.");
                              //  bm.drProcess("1");

                            } else if (speechInput.toLowerCase().contains("back")) {
                                Toast.makeText(combck.this, "Moving Back", Toast.LENGTH_LONG).show();
                                speak("Moving Back.");
                               // bm.drProcess("2");

                            } else if (speechInput.toLowerCase().contains("right")) {
                                Toast.makeText(combck.this, "Moving Right", Toast.LENGTH_LONG).show();
                                speak("Moving Right.");
                            //    bm.drProcess("3");

                            } else if (speechInput.toLowerCase().contains("left")) {
                                Toast.makeText(combck.this, "Moving Left", Toast.LENGTH_LONG).show();
                                speak("Moving Left.");
                              //  bm.drProcess("4");

                            } else if (speechInput.toLowerCase().contains("stop")) {
                                Toast.makeText(combck.this, "Stopped", Toast.LENGTH_LONG).show();
                                speak("Stopped moving.");
                               // bm.drProcess("0");

                            }
                        }
                        break;
                        default:
                            break;
                    }

                }

                @Override
                public void onPartialResults(Bundle partialResults) {
                    P.LogD("Chatting On onPartialResults");
                }

                @Override
                public void onEvent(int eventType, Bundle params) {
                    P.LogD("Chatting On onEvent");
                }
            });
        }
    }

    private String processResult(String command) {
        command = command.toLowerCase();
        return(command);
  /*      if(command.indexOf("go") != -1){
            if(command.indexOf("front") != -1){
                Toast.makeText(combck.this, "Moving Front", Toast.LENGTH_LONG).show();
            }
            if(command.indexOf("back") != -1){
                Toast.makeText(combck.this, "Moving Back", Toast.LENGTH_LONG).show();
            }
            if(command.indexOf("right") != -1){
                Toast.makeText(combck.this, "Moving Right", Toast.LENGTH_LONG).show();
            }
            if(command.indexOf("left") != -1){
                Toast.makeText(combck.this, "Moving Left", Toast.LENGTH_LONG).show();
            }
            } else if(command.indexOf("stop") != -1) {
            Toast.makeText(combck.this, "Stopped", Toast.LENGTH_LONG).show();
        }  */

    }

    public static String getErrorText(int errorCode) {
        String message;
        switch (errorCode) {
            case SpeechRecognizer.ERROR_AUDIO:
                message = "Audio recording error";
                break;
            case SpeechRecognizer.ERROR_CLIENT:
                message = "Client side error";
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                message = "Insufficient permissions";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
                message = "Network error";
                break;
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                message = "Network timeout";
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                message = "No match";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                message = "RecognitionService busy";
                break;
            case SpeechRecognizer.ERROR_SERVER:
                message = "error from server";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                message = "No speech input";
                break;
            default:
                message = "Didn't understand, please try again.";
                break;
        }
        return message;
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mySpeech != null) {
            mySpeech.destroy();
        }
    }

    void doPermAudio()
    {
        int MY_PERMISSIONS_RECORD_AUDIO = 1;
        combck thisActivity = this;

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(thisActivity,
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    MY_PERMISSIONS_RECORD_AUDIO);
        }
    }

}
