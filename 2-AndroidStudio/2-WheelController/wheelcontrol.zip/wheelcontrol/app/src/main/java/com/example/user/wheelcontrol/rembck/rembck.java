package com.example.user.wheelcontrol.rembck;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.user.wheelcontrol.R;
import com.example.user.wheelcontrol.bluetooth.bluetoothConnectionService;

public class rembck extends Activity {
    private static Button front, back, right, left, stop;
    private ImageView dire;
    private Integer[] img = {R.drawable.front, R.drawable.back, R.drawable.right, R.drawable.left, R.drawable.stop};
    private String TAG = "WheelChair";


    bluetoothConnectionService bms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.remo);
        front = (Button) findViewById(R.id.front);
        back = (Button) findViewById(R.id.back);
        right = (Button) findViewById(R.id.right);
        left = (Button) findViewById(R.id.left);
        stop = (Button) findViewById(R.id.stop);
        dire = (ImageView) findViewById(R.id.dire);
        bms = new bluetoothConnectionService(this);
       front.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Toast.makeText(rembck.this, "Moving Front", Toast.LENGTH_SHORT).show();
               dire.setImageResource(img[0]);
//               bms.mConnectedThread.write("1");

           }
       });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(rembck.this, "Moving Back", Toast.LENGTH_SHORT).show();
                dire.setImageResource(img[1]);
              // bm.drProcess("2");
                bms.mConnectedThread.write("1");
            }
        });

        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(rembck.this, "Moving Right", Toast.LENGTH_SHORT).show();
                dire.setImageResource(img[2]);
                // bm.drProcess("3");
            }
        });

        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(rembck.this, "Moving Left", Toast.LENGTH_SHORT).show();
                dire.setImageResource(img[3]);
                //bm.drProcess("4");
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(rembck.this, "Stopped", Toast.LENGTH_SHORT).show();
                dire.setImageResource(img[4]);
                 //bm.drProcess("0");
            }
        });

    }



}
