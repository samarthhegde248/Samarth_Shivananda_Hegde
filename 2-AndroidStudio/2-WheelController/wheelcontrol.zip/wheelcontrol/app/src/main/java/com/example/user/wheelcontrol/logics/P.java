package com.example.user.wheelcontrol.logics;

import android.telephony.SmsManager;
import android.util.Log;



import java.util.ArrayList;
import java.util.List;

/**
 * Created by admin on 27/01/2017.
 */
public class P {

    public static boolean canPrint=true;
    public static void LogD(String msg){
        Log.d("SmartAmbulance",msg);
    }

    //TO SEND SMS
    public static void sendSMS(String number,String msg){
        LogD("number : "+number+" msg : "+msg);
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(number, null, msg, null, null);
    }

    public static final int FOR_SPEECH_INPUT=0;
}
