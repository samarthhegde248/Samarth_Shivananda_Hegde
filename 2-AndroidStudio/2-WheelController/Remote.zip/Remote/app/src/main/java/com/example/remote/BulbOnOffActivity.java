package com.example.remote;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.UUID;


public class BulbOnOffActivity extends AppCompatActivity {
    private ImageView img_on_off_bulb;
    private Button btn_on_off_bulb, btn_mic_on_off_bulb;
//    @Bind(R.id.img_on_off_bulb)
//    ImageView img_on_off_bulb;
//    @Bind(R.id.btn_on_off_bulb)
//    Button btn_on_off_bulb;
//    @Bind(R.id.btn_mic_on_off_bulb)
//    Button btn_mic_on_off_bulb;
    private static boolean isBulbOn = false;
    private int WHAT = 0;
    private SpeechRecognizer mSpeechRecognizer;
    private Intent mSpeechRecognizerIntent;
    private boolean mIslistening = false;
    private String TAG = "BulbOnOff";
    private TextToSpeech t1;
    HashMap<String, String> params = new HashMap<String, String>();
    public static final String CONTROL = "control";
    public static final String ALERT = "alert";
    private Context context;

    //BLUETOOTH
    //ANOTHER SET

    /*Adapter helps to get a handler for device object which can be used to communicate with Bluetooth module*/
    private BluetoothAdapter btAdapter = null;
    /* Socket is used to connect and to get output/input streams to write/Read data To/From Bluetooth module */
    private BluetoothSocket btSocket = null;

    /* Output stream used to send data to Bluetooth module
     private OutputStream outStream = null;

    /* input stream used to read data from Bluetooth module */
    private InputStream inStream;

    // UUID is used as a key to connect to the device
    private final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // Insert your server's MAC address
    private String address = "98:D3:31:FB:47:46";
    Thread thread;
    OutputStream outStream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bulb_on_off);
//        ButterKnife.bind(this);
        img_on_off_bulb = (ImageView) findViewById(R.id.img_on_off_bulb);
        btn_on_off_bulb =(Button) findViewById(R.id.btn_on_off_bulb);
        btn_mic_on_off_bulb =(Button) findViewById(R.id.btn_mic_on_off_bulb);

        context = BulbOnOffActivity.this;
        speechRecognitionInit();
        t1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    t1.setLanguage(Locale.ENGLISH);
                    int isSpeechRate = t1.setSpeechRate(Float.parseFloat("0.9"));
                    P.LogD("isSpeechRate: " + isSpeechRate);
                    int isPitch = t1.setPitch(Float.parseFloat("0.8"));
                    P.LogD("isPitch: " + isPitch);
                }
            }
        });
        t1.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {

            }

            @Override
            public void onDone(String utteranceId) {
                switch (utteranceId) {
                    case CONTROL:
                        startListening();
                        break;
                    case ALERT:
                        //startListening();
                        break;
                }

            }

            @Override
            public void onError(String utteranceId) {

            }
        });
        btn_on_off_bulb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleBulb();
            }
        });

        btn_mic_on_off_bulb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ask("What Can I Do for You", CONTROL);
            }
        });

        img_on_off_bulb.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Intent intent = new Intent(context, BluetoothDemoActivity.class);
                startActivity(intent);
                return false;
            }
        });

        try {
            btAdapter = BluetoothAdapter.getDefaultAdapter();
            checkBTState();
            Runnable runnable = new Runnable() {
                @Override
                public void run() {

                }
            };
            thread = new Thread(runnable);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }


    }
    private void checkBTState() {
        if (btAdapter == null) {
        } else {
        }
    }
    private void ask(String msg, String key) {
        params.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, key);
        t1.speak(msg, TextToSpeech.QUEUE_FLUSH, params);//SPEECH OUTPUT
    }

    public void startListening() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                mSpeechRecognizer.startListening(mSpeechRecognizerIntent);

            }
        });
    }

    private void toggleBulb() {
        if (isBulbOn) {
            offBulb();
        } else {
            onBulb();
        }
    }

    private void onBulb() {
        sendDataToBluetooth("1");
        isBulbOn = true;
        img_on_off_bulb.setBackgroundResource(R.drawable.img_on);
        btn_on_off_bulb.setBackgroundResource(R.drawable.sw1);
    }

    private void offBulb() {
        sendDataToBluetooth("0");
        isBulbOn = false;
        img_on_off_bulb.setBackgroundResource(R.drawable.img_off);
        btn_on_off_bulb.setBackgroundResource(R.drawable.sw2);
    }

    public void speechRecognitionInit() {
        mSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        mSpeechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        mSpeechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        mSpeechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE,
                this.getPackageName());


        SpeechRecognitionListener listener = new SpeechRecognitionListener();
        mSpeechRecognizer.setRecognitionListener(listener);
    }

    protected class SpeechRecognitionListener implements RecognitionListener {

        @Override
        public void onBeginningOfSpeech() {
            P.LogD("onBeginningOfSpeech");
        }

        @Override
        public void onBufferReceived(byte[] buffer) {

        }

        @Override
        public void onEndOfSpeech() {
            P.LogD("onEndOfSpeech");
        }

        @Override
        public void onError(int errorCode) {
            mSpeechRecognizer.startListening(mSpeechRecognizerIntent);
            String errorMessage = getErrorText(errorCode);
            P.LogD("onError : " + errorMessage);
            if (errorMessage.equalsIgnoreCase("No match")) {
                return;
            }
            //Log.d(TAG, "error = " + error);
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
            P.LogD("Chatting On onEvent");
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
            P.LogD("Chatting On onPartialResults");
        }

        @Override
        public void onReadyForSpeech(Bundle params) {
            Log.d(TAG, "onReadyForSpeech"); //$NON-NLS-1$
            P.LogD("Chatting On onReadyForSpeech");
        }

        @Override
        public void onResults(Bundle results) {
            //Log.d(TAG, "onResults"); //$NON-NLS-1$
            ArrayList<String> result = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            // matches are the return values of speech recognition engine
            // Use these values for whatever you wish to do

            P.LogD("Chatting On onResult : " + result.get(0));
            switch (WHAT) {
                case P.FOR_SPEECH_INPUT: {
                    String speechInput = result.get(0).trim().replace(" ", "");
                    if (speechInput.toLowerCase().contains("on")) {
                        if (isBulbOn) {
                            ask("Bulb is already Switched ON", ALERT);
                        }
                        onBulb();
                    } else if (speechInput.toLowerCase().contains("off")) {
                        offBulb();
                    }

                }

                break;

                default:
                    break;
            }
        }

        @Override
        public void onRmsChanged(float rmsdB) {
        }


    }


    public static String getErrorText(int errorCode) {
        String message;
        switch (errorCode) {
            case SpeechRecognizer.ERROR_AUDIO:
                message = "Audio recording error";
                break;
            case SpeechRecognizer.ERROR_CLIENT:
                message = "Client side error";
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                message = "Insufficient permissions";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
                message = "Network error";
                break;
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                message = "Network timeout";
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                message = "No match";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                message = "RecognitionService busy";
                break;
            case SpeechRecognizer.ERROR_SERVER:
                message = "error from server";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                message = "No speech input";
                break;
            default:
                message = "Didn't understand, please try again.";
                break;
        }
        return message;
    }

    private void sendDataToBluetooth(final String message) {
        sendData(message);

    }

    @Override
    public void onResume() {
        super.onResume();
        // Set up a pointer to the remote node using it's address.
        BluetoothDevice device = btAdapter.getRemoteDevice(address);
        // Two things are needed to make a connection:
        //   A MAC address, which we got above.
        //   A Service ID or UUID.  In this case we are using the
        //     UUID for SPP.
        try {
            btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
        } catch (IOException e) {
            errorExit("Fatal Error", "In onResume() and socket create failed: " + e.getMessage() + ".");
        }
        // Discovery is resource intensive.  Make sure it isn't going on
        // when you attempt to connect and pass your message.
        btAdapter.cancelDiscovery();
        // Establish the connection.  This will block until it connects.
        try {
            btSocket.connect();
        } catch (IOException e) {
            try {
                btSocket.close();
            } catch (IOException e2) {

            }
        } catch (NullPointerException e) {
            e.printStackTrace();
            Toast.makeText(context, "Please check device pairing, device address", Toast.LENGTH_LONG).show();

        }
// Create a data stream so we can talk to server.
        try {
            outStream = btSocket.getOutputStream();
            inStream = btSocket.getInputStream();
            if (thread.getState() == Thread.State.NEW) {
                thread.start();
            }
        } catch (IOException e) {
        } catch (NullPointerException e) {
            e.printStackTrace();
            Toast.makeText(context, "Please check device pairing, device address", Toast.LENGTH_LONG).show();

        }
    }

    private void sendData(String message) {
        byte[] msgBuffer = message.getBytes();
        try {
            outStream.write(msgBuffer);
        } catch (IOException e) {
            String msg = "In onResume() and an exception occurred during write: " + e.getMessage();
            if (address.equals("00:00:00:00:00:00"))
                msg = msg + ".\n\nUpdate your server address from 00:00:00:00:00:00 to the correct address on line 37 in the java code";
            msg = msg + ".\n\nCheck that the SPP UUID: " + MY_UUID.toString() + " exists on server.\n\n";
            errorExit("Fatal Error", msg);
        }catch (NullPointerException e){
            e.printStackTrace();
        }
    }


    public void errorExit(String err, String msg) {
        P.LogD("Bluetooth : " + err + " | " + msg);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mSpeechRecognizer != null) {
            mSpeechRecognizer.destroy();
        }
    }

}

