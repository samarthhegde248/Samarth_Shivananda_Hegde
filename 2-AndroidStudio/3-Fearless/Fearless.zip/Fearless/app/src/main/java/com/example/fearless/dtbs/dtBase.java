package com.example.fearless.dtbs;

import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.example.fearless.registerbk;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class dtBase extends AsyncTask<String, Void, String> {
    AlertDialog dialog;
    Context context;
    public dtBase (Context context){
        this.context = context;
    }


    @Override
    protected void onPreExecute() {
        dialog = new AlertDialog.Builder(context).create();
        dialog.setTitle("Login Status");
    }

    @Override
    protected void onPostExecute(String s) {
        dialog.setMessage(s);
        dialog.show();
    }

    @Override
    protected String doInBackground(String... voids) {
        String result="";
        String type = voids[0];
        String connstr = "http://pmapindia.com/2018/cas/index.php/CASUserLogin_c.php/userLogin";
        String connstr1 = "http://pmapindia.com/2018/cas/index.php/CASUserRegister_c.php/userRegister";

        if(type.equals("login")) {
            try {
                String username = voids[1];
                String password = voids[2];
                URL url = new URL(connstr);
                HttpURLConnection http = (HttpURLConnection) url.openConnection();
                http.setRequestMethod("POST");
                http.setDoInput(true);
                http.setDoOutput(true);

                OutputStream ops = http.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(ops, "UTF-8"));
                String data = URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(username, "UTF-8")
                        + "&" + URLEncoder.encode("user_password", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8");
                writer.write(data);
                writer.flush();
                writer.close();
                ops.close();

                InputStream ips = http.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(ips, "ISO-8859-1"));
                String line = "";
                while ((line = reader.readLine()) != null) {
                    result += line;
                }
                reader.close();
                ips.close();
                http.disconnect();
                return result;


            } catch (MalformedURLException e) {
                result = e.getMessage();
            } catch (IOException e) {
                result = e.getMessage();
            }
        } else if(type.equals("register")) {
            try {
                String username = voids[1];
                String password = voids[2];
                String name = voids[3];
                String dob = voids[4];
                String blood = voids[5];
                String address = voids[6];
                String phno = voids[7];
                String phno1 = voids[8];
                String phno2 = voids[9];
                String phno3 = voids[10];
                String phno4 = voids[11];
                String phno5 = voids[12];
                String phno6 = voids[13];
                URL url = new URL(connstr1);
                HttpURLConnection http = (HttpURLConnection) url.openConnection();
                http.setRequestMethod("POST");
                http.setDoInput(true);
                http.setDoOutput(true);

                OutputStream ops = http.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(ops, "UTF-8"));
                String data = URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(username, "UTF-8") + "&"
                        +URLEncoder.encode("user_email", "UTF-8") + "=" + URLEncoder.encode(username, "UTF-8") + "&"
                        +URLEncoder.encode("user_mobile_number", "UTF-8") + "=" + URLEncoder.encode(phno, "UTF-8") + "&"
                        +URLEncoder.encode("user_password", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8") + "&"
                        +URLEncoder.encode("user_confirm_password", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8");
                writer.write(data);
                writer.flush();
                writer.close();
                ops.close();

                InputStream ips = http.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(ips, "ISO-8859-1"));
                String line = "";
                while ((line = reader.readLine()) != null) {
                    result += line;
                }
                reader.close();
                ips.close();
                http.disconnect();
                return result;


            } catch (MalformedURLException e) {
                result = e.getMessage();
            } catch (IOException e) {
                result = e.getMessage();
            }

        }

        return result;
    }
}

