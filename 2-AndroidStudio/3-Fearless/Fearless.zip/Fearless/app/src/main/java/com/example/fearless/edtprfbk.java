package com.example.fearless;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.fearless.dtbs.dtBase;

public class edtprfbk extends Activity {
    private Button regster;
    private EditText name, dob, blood, phno, phno1, phno2, phno3, phno4, phno5, phno6, mail, address, pass, repass;
    dtBase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edtprfr);
        regster = (Button) findViewById(R.id.register);
        name = (EditText) findViewById(R.id.name);
        dob = (EditText) findViewById(R.id.dob);
        blood = (EditText) findViewById(R.id.blood);
        phno = (EditText) findViewById(R.id.phno);
        phno1 = (EditText) findViewById(R.id.phno1);
        phno2 = (EditText) findViewById(R.id.phno2);
        phno3 = (EditText) findViewById(R.id.phno3);
        phno4 = (EditText) findViewById(R.id.phno4);
        phno5 = (EditText) findViewById(R.id.phno5);
        phno6 = (EditText) findViewById(R.id.phno6);
        mail = (EditText) findViewById(R.id.mail);
        address = (EditText) findViewById(R.id.address);
        pass = (EditText) findViewById(R.id.pass);
        repass = (EditText) findViewById(R.id.repass);


        regster.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            /*    String passc = repass.getText().toString();
                String passch = pass.getText().toString();
              if(passch==passc){
                    getDetails();
                    conductActivity5();
                }else{
                    Toast.makeText(edtprfbk.this,"Password didn't match.",Toast.LENGTH_SHORT).show();
                    return;
                }*/
            getDetails();
            }
        });
    }

    private void getDetails() {
        String nameq = name.getText().toString();
        String dobq = dob.getText().toString();
        String bloodq = blood.getText().toString();
        String phnoq = phno.getText().toString();
        String phnoq1 = phno1.getText().toString();
        String phnoq2 = phno2.getText().toString();
        String phnoq3 = phno3.getText().toString();
        String phnoq4 = phno4.getText().toString();
        String phnoq5 = phno5.getText().toString();
        String phnoq6 = phno6.getText().toString();
        String mailq = mail.getText().toString();
        String addressq = address.getText().toString();
        String passq = pass.getText().toString();
        String type = "register";
        dtBase db = new dtBase(this);
        db.execute(type, mailq, passq, nameq, dobq, bloodq, addressq, phnoq, phnoq1, phnoq2, phnoq3, phnoq4, phnoq5, phnoq6);
        Toast.makeText(edtprfbk.this,"Password didn't match.",Toast.LENGTH_SHORT).show();


    }

    private void conductActivity5() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();
        this.finish();
    }
}
