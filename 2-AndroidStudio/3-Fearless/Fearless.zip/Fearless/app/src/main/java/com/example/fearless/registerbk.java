package com.example.fearless;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SearchEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.example.fearless.bluetooth.bluetoothMain;
import com.example.fearless.dtbs.dtBase;
import com.google.android.gms.common.api.Api;

import java.util.UUID;

import static android.os.Build.VERSION_CODES.P;

public class registerbk extends Activity {
    private Button login;
    private Button signup;
    private EditText usr, psw;
    public static String result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registerfr);
        login = (Button)findViewById(R.id.login);
        signup = (Button)findViewById(R.id.signup);
        usr = (EditText) findViewById(R.id.username);
        psw = (EditText) findViewById(R.id.password);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                conductActivity4(v);
            }

        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                conductActivity5(v);
            }

        });
    }

    private void conductActivity5(View v) {

        Intent intent= new Intent(this,edtprfbk.class);
        startActivity(intent);

    }

    private void conductActivity4(View v) {
     String username = usr.getText().toString();
     String password = psw.getText().toString();
     String type = "login";
//        dtBase db = new dtBase(this);
//        db.execute(type, username, password);
       Intent intent= new Intent(this, bluetoothMain.class);
        startActivity(intent);

    }

    }
