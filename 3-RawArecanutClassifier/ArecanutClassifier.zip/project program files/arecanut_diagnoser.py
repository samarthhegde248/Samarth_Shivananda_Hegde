import cv2
import numpy as np
import time
from urllib import unquote_plus

video = cv2.VideoCapture(0)

while(1):
  
    
    (grabbed, frame) = video.read()
    if not grabbed:
        break
 
    blur = cv2.GaussianBlur(frame, (21, 21), 0)
    hsv = cv2.cvtColor(blur, cv2.COLOR_BGR2HSV)
 
    lower1 = [20, 100, 100]
    upper1 = [30, 255, 255]
    lower1 = np.array(lower1, dtype="uint8")
    upper1 = np.array(upper1, dtype="uint8")
    mask1 = cv2.inRange(hsv, lower1, upper1)
    
 
 
    output1 = cv2.bitwise_and(frame, hsv, mask=mask1)
    no_yellow1 = cv2.countNonZero(mask1)

    lower2 = [23, 41, 133]
    upper2 = [40, 150, 255]
    lower2 = np.array(lower2, dtype="uint8")
    upper2 = np.array(upper2, dtype="uint8")
    mask2 = cv2.inRange(hsv, lower2, upper2)
    
 
 
    output2 = cv2.bitwise_and(frame, hsv, mask=mask2)
    no_yellow2 = cv2.countNonZero(mask2)


    lower2 = [100, 0, 0]
    upper2 = [255, 80, 80]
    lower2 = np.array(lower2, dtype="uint8")
    upper2 = np.array(upper2, dtype="uint8")
    mask2 = cv2.inRange(hsv, lower2, upper2)
    
 
 
    output2 = cv2.bitwise_and(frame, hsv, mask=mask2)
    no_green1 = cv2.countNonZero(mask2)


    sensitivity = 15;
 
    lower3 = [60 - sensitivity, 100, 50] 
    upper3 = [60 + sensitivity, 255, 255]
    lower3 = np.array(lower3, dtype="uint8")
    upper3 = np.array(upper3, dtype="uint8")
    mask3 = cv2.inRange(hsv, lower3, upper3)
    
    output3 = cv2.bitwise_and(frame, hsv, mask=mask3)
    no_green2 = cv2.countNonZero(mask3)

    lower4 = [0, 0, 0]
    upper4 = [50, 50, 50]
    lower4 = np.array(lower4, dtype="uint8")
    upper4 = np.array(upper4, dtype="uint8")
    mask4 = cv2.inRange(hsv, lower4, upper4)
    
 
 
    output4 = cv2.bitwise_and(frame, hsv, mask=mask4)
    no_black = cv2.countNonZero(mask4)


    if int(no_yellow1) > 5000 :
            print 'yellow1, Non boiling'

    elif int(no_yellow2) > 5000 :
            print 'yellow2, Non boiling'

    elif int(no_green1) > 10000 :
            print 'green1, Boiling'

    elif int(no_green2) > 10000 :
            print 'green2, Boiling'

    elif int(no_black) >10000 :
            print 'black1, INFECTED'
                                          
    else:
            print 'Nothing'
         
            
cv2.destroyAllWindows() 

