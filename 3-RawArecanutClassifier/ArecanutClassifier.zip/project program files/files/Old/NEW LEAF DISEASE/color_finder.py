import RPi.GPIO as GPIO
import cv2
import numpy as np
import robot_next as rn 
import time
from urllib import unquote_plus

cap = cv2.VideoCapture(0)
rn.setUP()
rn.p2OFF()
rn.p1OFF()
rn.green_stop()
rn.grey_stop()
rn.yellow_stop()


while(1):
    #rn.setUP()
    rn.setUP()
    try:
        # Take each frame
        rev, frame = cap.read()       

        # Convert BGR to HSV
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        
#--------------------------------YELLOW-------------------------------------------------------------
        
        # Yellow Colour range of blue color in HSV
        lower_yellow = np.array([60,75,85],dtype=np.uint8)
        upper_yellow = np.array([70,100,97],dtype=np.uint8)

        
#---------------------------------GREEN------------------------------------------------------------        

        # Green Colour range o in HSV
        lower_green = np.array([125, 57, 43],dtype=np.uint8)
        upper_green = np.array([150, 100, 84],dtype=np.uint8)
      
#---------------------------------BROWN------------------------------------------------------------
        
        # Grey Colour range of blue color in HSV
        lower_grey = np.array([40,0,31],dtype=np.uint8)
        upper_grey = np.array([255,0,70],dtype=np.uint8)
    
#---------------------------------------------------------------------------------------------


#---------------------------------BROWN------------------------------------------------------------
        
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)   # replace green with frame

        # Threshold the HSV image to get only blue colors
        yellow_m = cv2.inRange(hsv, lower_yellow, upper_yellow)
        
        
#---------------------------------GREEN------------------------------------------------------------ 

        # Threshold the HSV image to get only Greem colors
        green_m = cv2.inRange(hsv, lower_green, upper_green)
        
#---------------------------------GRAY------------------------------------------------------------ 

        # Threshold the HSV image to get only Grey colors
        grey_m = cv2.inRange(hsv, lower_grey, upper_grey)

#---------------------------------------------------------------------------------------------         

        # Bitwise-AND mask and original image
        resy = cv2.bitwise_and(frame,frame, mask= yellow_m)
        resg = cv2.bitwise_and(frame,frame, mask= green_m)
        # resG = cv2.bitwise_and(frame,frame, mask= grey_m)

       
#greeen BLOCK********************************************************************************************


        if(green_m.any()):
            print 'Green found'
            print 'Stopping Motor1&2'
            rn.green_detect()
            rn.p2OFF()
            rn.p1OFF()
            rn.green_stop()
            rn.grey_stop()
            rn.yellow_stop()
                      
       
#yellow BLOCK********************************************************************************************
                               
        elif(yellow_m.any()):
            print'Yellow Found'
            print 'Starting Motor'
            #rn.grey_stop()
            #rn.yellow_detect()
            #rn.yellow_stop()
            rn.p2ON()
           # time.sleep(3)
           # rn.p1OFF()
            #rn.p2OFF()
      
            
#GRAY BLOCK********************************************************************************************
        elif(grey_m.any()):
            print'RED Found'
            #rn.yellow_stop()
            #rn.grey_detect()
            #time.sleep(3)
            #rn.grey_stop()
            rn.p2ON()
            #time.sleep(3)
            #rn.p2OFF()
                      
            

#Nothing BLOCK********************************************************************************************
           

        else:
            print 'Nothing'
            #rn.p2OFF()
            #rn.p1OFF()
            #rn.StopRobot()
            
        
        
    except KeyboardInterrupt:
        print 'Exiting Program'
        rn.relase()
        break
  
cv2.destroyAllWindows()
