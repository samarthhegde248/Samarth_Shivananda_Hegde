import RPi.GPIO as GPIO
from time import sleep


GPIO.setmode(GPIO.BOARD)

buttonCount = 3  # number of times the LED can be switched ON
count = 0
LEDPin = 8
buttonPin = 40

# Setup the pin the LED is connected to
GPIO.setup(LEDPin, GPIO.OUT)
# Setup the button
GPIO.setup(buttonPin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
#True to False
buttonPress = False  # Button is OFF
ledState = False

try:
    while count < buttonCount:
        print("Checking smoke !")
        buttonPress = GPIO.input(buttonPin)
        if ((not buttonPress) and (not ledState)):
            GPIO.output(LEDPin, True)  # LED ON
            print("Smoke Detected")
            ledState = True
            sleep(3)
        elif ((not buttonPress) and (ledState)):
            GPIO.output(LEDPin, False)  # LED OFF
            print("Smoke cleard")
            ledState = False
            count += 1
            sleep(.5)
        sleep(.1)
finally:
    # Reset the GPIO Pins to a safe state
	GPIO.output(LEDPin, False)    
	GPIO.cleanup()
