import RPi.GPIO as GPIO
import cv2
import numpy as np
import robot_next as rn 
import time
from urllib import unquote_plus

video = cv2.VideoCapture(0)
rn.setUP()
rn.p2OFF()
rn.p1OFF()
rn.green_stop()
rn.grey_stop()
rn.yellow_stop()


while(1):
    #rn.setUP()
    rn.setUP()
    
    (grabbed, frame) = video.read()
    if not grabbed:
        break
 
    blur = cv2.GaussianBlur(frame, (21, 21), 0)
    hsv = cv2.cvtColor(blur, cv2.COLOR_BGR2HSV)
 
    lower1 = [60, 75, 85]
    upper1 = [70, 100, 97]
    lower1 = np.array(lower1, dtype="uint8")
    upper1 = np.array(upper1, dtype="uint8")
    mask1 = cv2.inRange(hsv, lower1, upper1)
    
 
 
    output1 = cv2.bitwise_and(frame, hsv, mask=mask1)
    no_yellow = cv2.countNonZero(mask1)


  
    lower4 = [125, 57, 43]
    upper4 = [70, 255, 255]
    lower4 = np.array(lower4, dtype="uint8")
    upper4 = np.array(upper4, dtype="uint8")
    mask4 = cv2.inRange(hsv, lower4, upper4)


    output2 = cv2.bitwise_and(frame, hsv, mask=mask4)
    no_green = cv2.countNonZero(mask4)

    
       
    if int(no_yellow) > 10000 :
            print 'yellow'
            rn.p2ON()


            

    elif int(no_green) > 10000 :
            print 'Green'
            rn.p2ON()
    
                          
                                        

    else:
            print 'Nothing'
            rn.p2OFF()
            rn.p1OFF()
            #rn.StopRobot()
            
        

  
cv2.destroyAllWindows() 

