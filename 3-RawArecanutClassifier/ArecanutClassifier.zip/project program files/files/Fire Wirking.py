import cv2
import numpy as np
from twilio.rest import Client
a=0


account_sid = 'AC03ddc02cf149408e6cf39a2798f349a9'
auth_token = '7876af00a5faf94c1ba12c4941fc9757'
client = Client(account_sid, auth_token)
 
#video_file = "video_1.mp4"
video = cv2.VideoCapture(0)
 
while True:
    (grabbed, frame) = video.read()
    if not grabbed:
        break
 
    blur = cv2.GaussianBlur(frame, (21, 21), 0)
    hsv = cv2.cvtColor(blur, cv2.COLOR_BGR2HSV)
 
    lower = [18, 50, 50]
    upper = [35, 255, 255]
    lower = np.array(lower, dtype="uint8")
    upper = np.array(upper, dtype="uint8")
    mask = cv2.inRange(hsv, lower, upper)
    
 
 
    output = cv2.bitwise_and(frame, hsv, mask=mask)
    no_red = cv2.countNonZero(mask)
    cv2.imshow("input",frame )
    cv2.imshow("output", output)
    #print("output:", frame)
    if int(no_red) > 10000 :
        print ('Fire detected')
        message = client.messages \
        .create(
                body='Fire Detected Alert!',
                from_='+1201646-5148',
                to='+919591021721'
                )

        print(message.sid)
        
        break
        
    #print(int(no_red))
   #print("output:".format(mask))
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
 
cv2.destroyAllWindows()
video.release()