

# ===== Your specific configuration goes below / please adapt ========

# the HCP account id - trial accounts typically look like p[0-9]*trial
hcp_account_id='p1942367811trial'

# you only need to adapt this part of the URL if you are NOT ON TRIAL but e.g. on PROD
hcp_landscape_host='.hanatrial.ondemand.com'
# hcp_landscape_host='.hana.ondemand.com' # this is used on PROD
# hcp_landscape_host='.cert.hana.ondemand.com' # this is used on PROD with Client Certificate Authentication

endpoint_certificate = "./hanatrial.ondemand.com.crt"
# you can download this certificate file with your browser from the app server in your landscape - it is used to check that the server is authentic
# we also provide the certificate that is valid in July 2016 at our github repo

# to use Client Certificate Authentication (works only on PROD) you need to use the respective landscape and authenticate the device by specifying the client certificate and key; in this case the OAuth token can be skipped
# client_certificate = "./Device.crt"
# client_key = "./Device.key"

# the following values need to be taken from the IoT Cockpit
device_id='882e6bb2-9bb8-4b24-96b5-d84af249a6f0'

# the device specific OAuth token is used as MQTT password
oauth_credentials_for_device='3e69c5a99a12934c7352ca2a6d3e9d'

message_type_id_From_device='e95203b365bbf2f09c0f'

# ===== nothing to be changed / configured below this line ===========
