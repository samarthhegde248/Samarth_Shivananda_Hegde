import RPi.GPIO as GPIO
import time
from urllib import unquote_plus


#GPIO.setmode(GPIO.BOARD)
#setUP()

def setUP():
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)

    GPIO.setup(11,GPIO.OUT)               # Green Indicator
    #GPIO.output(11,GPIO.LOW)

    GPIO.setup(12,GPIO.OUT)               # Brown indicator
    #GPIO.output(25,GPIO.LOW)

    GPIO.setup(4,GPIO.OUT)
    #GPIO.output(4,GPIO.LOW)

    GPIO.setup(13,GPIO.OUT)
      
    GPIO.setup(9,GPIO.OUT)              # LED to indicate conncetion status
                                        # IN1    for pump 1 and Make In2 gnd
    GPIO.output(13,GPIO.LOW)                
    GPIO.setup(6,GPIO.OUT)               # IN3    for pump 2 and make in4 gnd
    #GPIO.output(6,GPIO.LOW)
    # main loop try

  
def p1ON():
    #setUP()
    #time.sleep(0.2)
    GPIO.output(13,GPIO.HIGH)              # IN1    for pump 1 and Make In2 gnd
    #time.sleep(3)
    #GPIO.output(26,GPIO.LOW)
    #GPIO.cleanup()


def p1OFF():
    #setUP()
    #time.sleep(0.2)
    GPIO.output(13,GPIO.LOW)              # IN1    for pump 1 and Make In2 gnd
    #GPIO.cleanup()
    

def p2OFF():
    #setUP()
    GPIO.output(6,GPIO.LOW)              # IN1    for pump2 and Make In2 gnd
    #GPIO.cleanup()


def p2ON():
    #setUP()
    GPIO.output(6,GPIO.HIGH)              # IN1    for pump2 and Make In2 gnd
    #time.sleep(3)
    #GPIO.output(6,GPIO.LOW)
    #GPIO.cleanup()

def yellow_detect():
    #setUP()                           # Yellow indicator
    GPIO.output(12,GPIO.HIGH)
    #time.sleep(0.1)
    #GPIO.cleanup()

def green_detect():
    #setUP()                                # Green indicator
    GPIO.output(11,GPIO.HIGH)
    #time.sleep(0.1)
    #GPIO.cleanup()

def green_stop():
    #setUP()                                # Green indicator
    GPIO.output(11,GPIO.LOW)
    #GPIO.cleanup()

def yellow_stop():
    #setUP()                                # Green indicator
    GPIO.output(12,GPIO.LOW)
    #GPIO.cleanup()


def grey_detect():
    #setUP()                
    GPIO.output(4,GPIO.HIGH)
    #time.sleep(5)
    #GPIO.cleanup()

def grey_stop():
    #setUP()
    GPIO.output(4,GPIO.LOW)
    #GPIO.cleanup()

def relase():
    GPIO.cleanup()
    
    

    
    

#
# main loop
#

# add serial port service
#subprocess.call(['sudo', 'sdptool', 'add', 'SP'])



    
   
