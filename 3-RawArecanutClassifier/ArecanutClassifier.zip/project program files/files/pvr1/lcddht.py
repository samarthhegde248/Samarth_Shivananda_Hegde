#!/usr/bin/python
# Import required Python libraries
import time
import RPi.GPIO as GPIO
import Adafruit_CharLCD as LCD
import Adafruit_DHT

# Use BCM GPIO references
# instead of physical pin numbers
GPIO.setmode(GPIO.BCM)

# Define GPIO to use on Pi
GPIO_TRIGGER = 5
GPIO_ECHO = 6
GPIO_LED=12
lcd_rs        = 27  # Note this might need to be changed to 21 for older revision Pi's.
lcd_en        = 22
lcd_d4        = 25
lcd_d5        = 24
lcd_d6        = 23
lcd_d7        = 18
lcd_backlight = 4

lcd_columns = 16
lcd_rows    = 2

# Alternatively specify a 20x4 LCD.
# lcd_columns = 20
# lcd_rows    = 4

# Initialize the LCD using the pins above.
lcd = LCD.Adafruit_CharLCD(lcd_rs, lcd_en, lcd_d4, lcd_d5, lcd_d6, lcd_d7,
                           lcd_columns, lcd_rows, lcd_backlight)

print "Ultrasonic Measurement"

# Set pins as output and input
GPIO.setup(GPIO_TRIGGER,GPIO.OUT)  # Trigger
GPIO.setup(GPIO_ECHO,GPIO.IN)      # Echo
GPIO.setup(GPIO_LED,GPIO.OUT) 
def distance():
    
    # Set trigger to False (Low)
    while True:
        humidity, temperature = Adafruit_DHT.read_retry(11, 27)  # GPIO27 (BCM notation)
        print ("Humidity = {} %; Temperature = {} C".format(humidity, temperature))

     
       lcd.message(temperature)
       # Wait 5 seconds
       time.sleep(5.0)

       # Demo showing the cursor.
       lcd.clear()
    
    

    return temperature,humidity

if __name__ == '__main__':
    try:
        while True:
            dist = distance()
            print "Distance : %.1f" % dist
            time.sleep(1)
            
            
            # Reset by pressing CTRL + C
    except KeyboardInterrupt:
        print("Measurement stopped by User")
        GPIO.cleanup()
