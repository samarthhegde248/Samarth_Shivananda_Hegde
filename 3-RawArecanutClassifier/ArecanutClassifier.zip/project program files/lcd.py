
import RPi.GPIO as GPIO 
import time
from RPLCD import CharLCD

# Configure the LCD
lcd = CharLCD(pin_rs = 19, pin_rw = None, pin_e = 16, pins_data = [21,18,23,24], 
numbering_mode = GPIO.BOARD)

# Create a variable ‘number’ 
lcd.write_string('kit')
time.sleep(1)

# Main loop(1)

while(True):
        lcd.clear()
# Increment the number and then print it to the LCD number = number + 1
        lcd.write_string('kit')
        time.sleep(1)
    

    
GPIO.cleanup()
